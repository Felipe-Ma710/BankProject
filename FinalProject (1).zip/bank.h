#ifndef BANK_H
#define BANK_H
#include <string>
#include <vector>
#include "bankaccount.h"
#include "savingaccount.h"
//#include <bits/stdc++.h>
#include <algorithm>
using namespace std;

class Bank{
protected:
string bankName;
string bankAddress;
string bankHours;
int count=10000;
vector<bankAccount> bankAccounts;
public:
    //vector<bankAccount> bankAccounts; 
    Bank(){
        bankName = "N/A";
        bankAddress = "N/A";
        bankHours = "N/A";
    }
    Bank(string bankName, string bankAddress, string bankHours){
      this->bankName = bankName;
      this->bankAddress = bankAddress;
      this->bankHours = bankHours;
    }
    void setBankName(string bankName){this->bankName = bankName;}
    void setBankAddress(string bankAddress){this->bankAddress = bankAddress;}
    void setBankHours(string bankHours){this->bankHours = bankHours;}

    string getBankName()const{return this->bankName;}
    string getBankAddress()const{return this->bankAddress;}
    string getBankHours()const{return this->bankHours;}

  ///////////////////////////////////////////////////////////////////
    void bankServices(){
      bool bankServicesRunning = true;
      while(bankServicesRunning){
        cout << "Eligible services for " << getBankName() << endl;
        cout << "        A -- Number of Bank-Accounts" << endl;
        cout << "        S -- Number of Saving-Accounts" << endl;
        cout << "        H -- Number of Checking-Accounts" << endl;
        cout << "        O -- Open Bank-Account" << endl;
        cout << "        C -- Close Bank-Account" << endl;
        cout << "        M -- Modify Bank-Account" << endl;
        cout << "        D -- Detailed Bank-Accounts" << endl;
        cout << "        B -- Brief Bank-Accounts Info sorted Base on Aggregated Balances" << endl;
        cout << "        X -- Exit" << endl;
        cout << "Please enter your selection: ";
        string selection;
        getline(cin, selection);
        cout << endl;
      
        if(selection == "A" || selection == "a"){//ENTER "A"-> # of bank accounts
          printNumBankAccounts();
        }
        if(selection == "S" || selection == "s"){//ENTER "S"-> # of saving accounts
          printNumSavingAccounts();
        }
        if(selection == "H" || selection == "h"){//ENTER "H"-> # of checking accounts
          printNumCheckingAccounts();
        }
        if(selection == "O" || selection == "o"){//ENTER "O"-> Open Bank Account
          openBankAccount();
        }
        if(selection == "C" || selection == "c"){//ENTER "C"-> Close Bank Account
          removeBankAccount();
        }
        if(selection == "M" || selection == "m"){//ENTER "M"-> Modify Bank Account
        modifyAccount();
        }
        if(selection == "D" || selection == "d"){//ENTER "D"-> Detailed Bank Accounts
          printDetailedBankAccounts();
          printBankAccounts();

        }
        if(selection == "B" || selection == "b"){
          briefBank();
        }
        if(selection == "X" || selection == "x"){//ENTER "X"-> Exit
          endBank();
          bankServicesRunning = false;
        }
      }
    }
///////////////////////////////////////////////////////////////////
    void printNumBankAccounts(){//print number of bank accounts
      cout << "|  The number of Bank-Account(s) is " << bankAccounts.size() << endl << endl;
    }
    void printNumSavingAccounts(){//print number of saving accounts
      cout << "|  The number of Saving-Account(s) is ";
      int savCount;
      for(auto i: bankAccounts){
        savCount += i.getSavNum();
      }
        cout << savCount << endl << endl;
    }
    void printNumCheckingAccounts(){
      cout << "|  The number of Checking-Account(s) is ";
      int checkCount;
      for(auto i: bankAccounts){
        checkCount += i.getCheckNum();
      }
      cout << checkCount << endl << endl;
    }
    void openBankAccount(){//print and open a bank account
      string firstName, lastName, SSN;
      cout << "|  Enter the first name of the account holder: ";
      getline(cin,firstName);
      cout << "|  Enter the last name of the account holder: ";
      getline(cin, lastName);
      cout << "|  Enter the SSN of the account holder: ";
      getline(cin,SSN);
      cout << endl;
      createNewBankAccount(firstName, lastName, SSN);
    }
    //create a new bank account that pushes back into vector bankAccounts
    void createNewBankAccount(const string firstName, const string lastName, const string SSN){
        int bankAccountNumber = 10000+count;
        bankAccount account(firstName, lastName, SSN, bankAccountNumber);
        bankAccounts.push_back(account);
        cout << "|  A new Bank Account BNK" << 10000+count << " was successfully created" << endl << endl;
        count++;
        bankAccounts.at(count-10000).bankAccountMenu();
        
    }
    //remove a bank account given account number
    void removeBankAccount(){
      int account;
      cout << "|  Enter the bank account number to be removed: BNK";
      cin >> account;
      cin.ignore(256, '\n');
      for(vector<bankAccount>::iterator it = bankAccounts.begin(); it != bankAccounts.end()+1; it++){
        if(it->getBankAccountNumber() == account){
          bankAccounts.erase(it);
          cout << "Bank Account " << account << " successfully removed " << endl << endl;
          break;
        }
        else if(it == bankAccounts.end()){
          cout << "Account not found" << endl;
        }
        else{
          cout << "searching...." << endl;
        }
      }
    }
    void modifyAccount(){
      int account;
      cout << "|  Enter the bank account number to be modified: BNK";
      cin >> account;
      cin.ignore(256, '\n');
      int j=0;
      for(vector<bankAccount>::iterator it = bankAccounts.begin(); it != bankAccounts.end()+1; it++){
        if(it->getBankAccountNumber() == account){
          cout << "Found bank account!" << endl << endl;
          bankAccounts.at(j).bankAccountMenu();
          j=0;//reset
          break;
        }
        else if(it == bankAccounts.end()){
          cout << "account not found " << endl;
        }
        else{
          cout << "searching..." << endl;
          j++;
        }
      }
      cout << endl;
    }
    void printDetailedBankAccounts(){//print detailed bank accounts
      cout << "|  Bank Name: " << getBankName() << endl;
      cout << "|  Bank Address: " << getBankAddress() << endl;
      cout << "|  Bank Working Hours: " << getBankHours() << endl;
      cout << "|  Aggregated Balance: " << endl;
      cout << "|  Consists of " << bankAccounts.size() << " Bank-Account(s)" << endl << endl;
      //printBankAccounts();
      }

    void endBank(){
      cout << "|  End of Service for " << getBankName() << endl;
    }
    void printBankAccounts(){//print vector of bank accounts
      for(auto i: bankAccounts){
        i.printInfoBankAccount();
      }
    }
    void briefBank(){
      printDetailedBankAccounts();
      for(auto i: bankAccounts){
      i.briefBankInfo();
      cout << endl;
      }
    }
};
#endif
