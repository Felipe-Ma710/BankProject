#include <iostream>
#include <string>
#include "bank.h"
using namespace std;


int main() {
    bool running = true;
      string bankName, bankAddress, bankWorkingHours;
      cout << "Enter the name of the bank: ";
      getline(cin, bankName);
      cout << "Enter the address of the bank: ";
      getline(cin, bankAddress);
      cout << "Enter the working hours: ";
      getline(cin, bankWorkingHours);
      cout << endl;
      Bank newBank(bankName, bankAddress, bankWorkingHours);
      newBank.bankServices();
      return 0;
}
