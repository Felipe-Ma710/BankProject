#pragma once
using namespace std;
static int checkingAccCount = 0;
class checkingAccount{
protected:
  int maxCapacity;
  int balance;
  bool accountLock;
  int checkingAccountNumber;
public:
  checkingAccount(const int initialBalance, const int maxCapacity, bool checkLock){
    this->balance = initialBalance;
    this->maxCapacity = maxCapacity;
    accountLock=checkLock;
    this->checkingAccountNumber = 6000 + checkingAccCount;
    cout << "A new Checking Sub-account CHK" << checkingAccountNumber << " was created with a balance of " << balance << endl << endl;
    checkingAccCount++;
  }
  int getCheckingAccountNumber()const{return this->checkingAccountNumber;}
  int getCheckingAccountBalance()const{return this->balance;}
  int getCheckingMaxCapacity()const{return this->maxCapacity;}
  bool getCheckingLock()const{return accountLock;}
  
  void printInfoChk(){
    cout << "|  Sub-account number: CHK" << getCheckingAccountNumber() << endl;
    cout << "|  Balance: " << getCheckingAccountBalance() << endl;
    cout << "|  The maximum capacity is: " << getCheckingMaxCapacity() << endl;
    cout << "|  The sub-account is ";
    if(getCheckingLock() == 1){
      cout << "locked." << endl;
    }
    else{
      cout << "unlocked." << endl;
    }
    cout << endl << endl;
  }
  void checkingMenu(){
    bool checkRunning = true;
    while(checkRunning){
      cout << "Eligible Services for CHK" << checkingAccountNumber << endl;
      cout << "        D--Deposit" << endl;
      cout << "        W--Withdrawal" << endl;
      cout << "        C--Max Capacity" << endl;
      cout << "        L--Lock Sub-Account" << endl;
      cout << "        U--Unlock Sub-Account" << endl;
      cout << "        X-Exit" << endl;

      cout << "Please enter your selection: ";
      string checkSelection;
      cin >> checkSelection;
      cin.ignore(256, '\n');
      cout << endl;


      if(checkSelection == "D" || checkSelection == "d"){
        checkingDeposit();
      }
      if(checkSelection == "W" || checkSelection == "w"){
        checkingWithdrawal();
      }
      if(checkSelection == "C" || checkSelection == "c"){
        changeMax();
      }
      if(checkSelection == "L" || checkSelection == "l"){
        lockAccount();
      }
      if(checkSelection == "U" || checkSelection == "u"){
        unlockAccount();
      }
      if(checkSelection == "X" || checkSelection == "x"){
        cout << "|  End of service for CHK" << checkingAccountNumber << endl;
        checkRunning = false;
      }
    }
  }
  void checkingDeposit(){
    cout << "Enter the amount to deposit: ";
    int depositAmount;
    cin >> depositAmount;
    cout << endl;
    if(accountLock == 1){
      cout << "|  The account is currently locked!" << endl;
      cout << "|  The deposit was unsuccessful!" << endl;
      cout << "|  The current balance is " << balance << endl;
    }
    else{
      int check;
      check = balance + depositAmount;
      if(check > maxCapacity){
        cout << "|  The max capacity is " << maxCapacity << "!" << endl;
        cout << "|  The deposit was unsuccessful!" << endl;
        cout << "|  The current balance is " << balance << endl << endl;
        return;
      }
      cout << "|  Deposit was successful!" << endl;
      balance += depositAmount;
      cout << "|  The current balance is " << balance << endl;
    }
    cout << endl;
  }
  void checkingWithdrawal(){
    cout << "|  Enter the amount to withdrawal: ";
    int withdrawalAmount;
    cin >> withdrawalAmount;
    if(accountLock == 1){
      cout << "|  The account is currently locked!" << endl;
      cout << "|  The withdrawal was unsuccessful!" << endl;
    }
    else{
      cout << "|  Withdrawal was successful!" << endl;
      balance -= withdrawalAmount;
      cout << "|  The current balance is " << balance << endl;
    }
    cout << endl;
  }
  void changeMax(){
    cout << "Enter the new max capacity: ";
    int maxCap;
    cin >> maxCap;
    maxCapacity = maxCap;
    cout << "New max capacity is " << maxCapacity << endl << endl;
  }
  void lockAccount(){
    cout << "|  The Sub-account CHK" << checkingAccountNumber << " is locked now" << endl;
    accountLock = true;
  }
  void unlockAccount(){
    cout << "|  The Sub-account CHK" << checkingAccountNumber << " is unlocked now" << endl << endl;
    accountLock = false;
  }
};