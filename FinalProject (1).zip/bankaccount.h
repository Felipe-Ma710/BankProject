#ifndef BANKACCOUNT_H
#define BANKACCOUNT_H
#include <string>
#include "savingaccount.h"
#include "checkingaccount.h"
#include "bank.h"
using namespace std;

class bankAccount{
  protected:
    string firstName, lastName, SSN, savingAccountNumber;
    int bankAccountNumber;
    vector<savingAccount>savingAccounts;
    vector<checkingAccount>checkingAccounts;
  public:
    bankAccount(){
      firstName = "N/A";
      lastName = "N/A";
      SSN = "N/A";
      bankAccountNumber = 1000;
    }
    bankAccount(const string firstName, const string lastName, const string SSN, int bankAccountNumber){
      this->firstName = firstName;
      this->lastName = lastName;
      this->SSN = SSN;
      this->bankAccountNumber = bankAccountNumber;
    }
    string getFirstName()const{return this->firstName;}
    string getLastName()const{return this->lastName;}
    string getSSN()const{return this->SSN;}
    int getBankAccountNumber()const{return this->bankAccountNumber;}
    int getSavNum()const{return savingAccounts.size();}
    int getCheckNum()const{return checkingAccounts.size();}

    void bankAccountMenu(){
      bool bankAccRunning = true;
      while(bankAccRunning){
        cout << "Eligible services for BNK" << getBankAccountNumber() << endl;
        cout << "      S--Open Saving Sub-Account" << endl;
        cout << "      C--Open Checking Sub-Account" << endl;
        cout << "      M--Modify a Sub-Account" << endl;
        cout << "      E--Close a Sub-Account" << endl;
        cout << "      D--Detailed Bank Account Info Sorted Based on Balances of Sub-accounts" << endl;
        cout << "      B--Brief Bank Account Info" << endl;
        cout << "      X--Exit" << endl;
        string bankAccselection;
        cout << "Please enter your selection: ";
        getline(cin, bankAccselection);
        cout << endl;
        //cin.ignore(256, '\n');
        if(bankAccselection == "S" || bankAccselection == "s"){
          createNewSavingAccount();
          cout << endl;
        }
        if(bankAccselection == "C" || bankAccselection == "c"){
          createNewCheckingAccount();
        }
        if(bankAccselection == "M" || bankAccselection == "m"){
          modifySub();
          cout << endl;
        }
        if(bankAccselection == "E" || bankAccselection == "e"){
          closeSub();
        }
        if(bankAccselection == "B" || bankAccselection == "b"){
          briefBankInfo();
        }
        if(bankAccselection == "D" || bankAccselection == "d"){
          detailBankAcc();
        }
        if(bankAccselection == "X" || bankAccselection == "x"){
          cout << "|  End of service for BNK" << getBankAccountNumber() << endl;
          bankAccRunning = false;
        }
      }
      cout << endl;
    }
    //print function for printing bank account name, SSN
    void printInfoBankAccount(){
      cout << "|  Bank Account Number: BNK" << getBankAccountNumber() << endl;
      cout << "|  Account Holder Full Name: " << getFirstName() <<  " " << getLastName() << endl;
      cout << "|  Account Holder SSN: " << getSSN() << endl;
      cout << "|  Aggregated Balance: " ;
      bankAggregated();
      cout << endl;
      cout << "|  Consists of " << savingAccounts.size() + checkingAccounts.size() << " Sub-Account(s)" << endl;
      cout << endl;
      printDetailSub();
    }
    void createNewSavingAccount(){
      int initialBalance;
      cout << "|  Enter the initial balance : ";
      cin >> initialBalance;
      cin.ignore(256, '\n');
      if(savingAccounts.size()==0){
        initialBalance += 100;
      }
      savingAccount savAccount(initialBalance);
      savingAccounts.push_back(savAccount);
      cout << endl;
    }
    void createNewCheckingAccount(){
      int initialBalance, maxCapacity;
      bool checkLock;
      string lock;
      cout << "|  Enter the initial balance: ";
      cin >> initialBalance;
      cin.ignore(256, '\n');
      cout << "|  Enter the desired maximum capacity: ";
      cin >> maxCapacity;
      cin.ignore(256, '\n');
      cout << "|  Define initial state: (L-Locked, Otherwise - Unlocked): ";
      cin >> lock;
      cin.ignore(256, '\n');
      cout << endl;

      if(lock == "L" || lock == "l"){
        checkLock = true;
        checkingAccount checkAcc(initialBalance, maxCapacity, checkLock);
        checkingAccounts.push_back(checkAcc);
      }
      else{
        checkLock = false;
        checkingAccount checkAcc(initialBalance, maxCapacity, checkLock);
        checkingAccounts.push_back(checkAcc);
      }
    }
    void modifySub(){
      bool modifySubRunning = true;
      while(modifySubRunning){
      string subType;
      int accNum;
      cout << "Enter the sub type to Modify: ";
      cin >> subType;
      cin.ignore(256, '\n');
      if(subType == "SAV"){
        int savModify;
        cout << "Enter the SAV Account number to modify: SAV";
        cin >> savModify;
        cin.ignore(256, '\n');
        cout << endl;
        int j = 0;
        for(vector<savingAccount>::iterator it = savingAccounts.begin(); it != savingAccounts.end()+1; it++){
          if(it->getSavingAccountNumber() == savModify){
            cout << "Found savings account!" << endl << endl;
            cout << endl;
            savingAccounts.at(j).savingMenu();
            j=0; //reset
            modifySubRunning = false;
            break;
          }
          else if(it == savingAccounts.end()){
            cout << "Savings account not found!" << endl;
            modifySubRunning = false;

          }
          else{
            cout << "searching..." << endl;
            j++;
          }
        }
        cout << endl;
      }
      else if(subType == "CHK"){
         int checkModify;
        cout << "Enter the CHK account number to modify: CHK";
        cin >> checkModify;
        cin.ignore(256,'\n');
        cout << endl;
        int j=0;
        for(vector<checkingAccount>::iterator it = checkingAccounts.begin(); it != checkingAccounts.end()+1; it++){
          if(it->getCheckingAccountNumber() == checkModify){
            cout << "Found checking account!" << endl << endl;
            //cout << "Vector at " << j << endl;
            checkingAccounts.at(j).checkingMenu();
            modifySubRunning = false;
            j=0; // reset
            break;
          }
          else if(it == checkingAccounts.end()){
            cout << "Checking account not found!" << endl;
            modifySubRunning = false;
          }
          else{
            cout << "searching..." << endl;
            j++;
          }
        }
      }
      else{
        cout << "Invalid Input, returning to Menu" << endl;
        modifySubRunning = false;
      }
    }
    }
    void closeSub(){
      bool closeRunning = true;
      while(closeRunning){
        string subType;
        cout << "Enter the sub type to modify: ";
        cin >> subType;
        cin.ignore(256, '\n');
        if(subType == "SAV"){
          int savModify;
          cout << "Enter the SAV Account number to modify: SAV";
          cin >> savModify;
          cin.ignore(256, '\n');
          cout << endl;
          for(vector<savingAccount>::iterator it = savingAccounts.begin(); it != savingAccounts.end()+1; it++){
            if(it->getSavingAccountNumber() == savModify){
              savingAccounts.erase(it);
              cout << "|  Sub-account SAV" << savModify << " was successfully closed!" << endl << endl;
              closeRunning = false;
            }
            else if(it == savingAccounts.end()){
              cout << "Savings account not found!" << endl;
              closeRunning = false;
            }
            else{
              cout << "searching..." << endl;
            }
          }
        }
        else if(subType == "CHK"){
          int checkModify;
          cout << "Enter the CHK Account number to modify: CHK";
          cin >> checkModify;
          cin.ignore(256, '\n');
          cout << endl;
          for(vector<checkingAccount>::iterator it = checkingAccounts.begin(); it != checkingAccounts.end()+1; it++){
            if(it->getCheckingAccountNumber() == checkModify){
              checkingAccounts.erase(it);
              cout << "|  Sub-account CHK" << checkModify << " was successfully closed!" << endl << endl;
              closeRunning = false;
            }
            else if(it == checkingAccounts.end()){
              cout << "Checking account not found!" << endl;
              closeRunning = false;
            }
            else{
              cout << "searching..." << endl;
            }
          }
        }
        else{
          cout << "Invalid Input, returning to Menu" << endl;
          closeRunning = false;      
        }
      }
    }
    void briefBankInfo(){
      cout << "|  Aggregated Balance of the bank account : BNK" << getBankAccountNumber() << " with " << savingAccounts.size() + checkingAccounts.size() << " Sub-accounts is " ;
      bankAggregated();
      cout << endl << endl;
    }
    void bankAggregated(){
      int balance = 0;
      for(auto i: savingAccounts){
        balance += i.getSavingAccountBalance();
      }
      for(auto i: checkingAccounts){
        balance += i.getCheckingAccountBalance();
      }
      cout << balance;
    }
    void detailBankAcc(){
      printDetailSub();
      cout << endl;
    }
    void printDetailSub(){
      for(auto i: savingAccounts){
        i.printInfoSav();
      }
      for(auto i: checkingAccounts){
        i.printInfoChk();
      }
    }
};
#endif
