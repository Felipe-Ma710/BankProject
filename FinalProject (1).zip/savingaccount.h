#ifndef SAVINGACCOUNT_H
#define SAVINGACCOUNT_H
#include "bankaccount.h"
#include <sstream>
using namespace std;
static int savingAccCount = 0;

class savingAccount{
  protected:
    int savingAccountNumber;
    int balance;
  public:
    savingAccount(const int initialBalance){
      this->balance = initialBalance;
      this->savingAccountNumber = 1000+savingAccCount;
      cout << "|  A new Saving Sub-account SAV" << savingAccountNumber << " was created with balance of " << balance << endl;
      savingAccCount++;
    }

    int getSavingAccountNumber()const{return this->savingAccountNumber;}
    int getSavingAccountBalance()const{return this->balance;} 
    
    void printInfoSav(){
      cout << "|  Sub-account number: SAV" << getSavingAccountNumber() << endl;
      cout << "|  Balance: " << getSavingAccountBalance() << endl;
      cout << endl << endl;
    }
    void savingMenu(){
      bool savMenuRunning = true;
      while(savMenuRunning){
      cout << "Eligible Services for Sub-account SAV" << savingAccountNumber << endl;
      cout << "        D--Deposit" << endl;
      cout << "        W--Withdrawal" << endl;
      cout << "        X--Exit" << endl;
      string savSelection;
      cout << "Please enter your selection: ";
      cin >> savSelection;
      cin.ignore(256, '\n');

      
      if(savSelection == "D" || savSelection == "d"){
        savingDeposit();
      }
      if(savSelection == "W" || savSelection == "w"){
        savingWithdrawal();
      }
      if(savSelection == "X" || savSelection == "x"){
        cout << "|  End of service for sub-account SAV" << savingAccountNumber <<  endl;
        savMenuRunning = false;
      }
      }
    }
    void savingDeposit(){
      cout << "Enter the amount to deposit: ";
      int depositAmount;
      cin >> depositAmount;
      balance += depositAmount;
      cout << "|  Deposit was successful." << endl;
      cout << "|  The current balance is " << balance << endl << endl;
    }
    void savingWithdrawal(){
      cout << "Enter the amount to withdrawal: ";
      int withdrawalAmount;
      cin >> withdrawalAmount;
      balance -= withdrawalAmount;
      cout << "|  Withdrawal was successful." << endl;
      cout << "|  The current balance is " << balance << endl << endl;
    }
};

#endif
